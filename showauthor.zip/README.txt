=== ShowAuthor ===
Tags: author
Contributors: Ranveer Kunal (ranveerkunal@gmail.com)
Requires at least: 1.5
Tested up to: 2.7.x
Stable tag: 2.7

ShowAuthor plugin add author details to selected spots on the blog.

== Description ==

ShowAuthor is extremely simple plugin, whose functionality is quite clear from the name. There is an Options page too, which allows you to customize it.

== Installation ==

1. Download the plugin archive and expand it (you've likely already done this).
2. Put the 'sharethis.php' file into your wp-content/plugins/ directory.
3. Go to the Plugins page in your WordPress Administration area and click 'Activate' for ShowAuthor.
4. (Optional) Go to http://sharethis.com/wordpress to customize your widget, then copy the code provided and paste it into the box in Options > ShowAuthor and click the update button.
5. (Optional) On the ShowAuthor Options page, choose the customizations you want.
